import React, { useState } from 'react';
import './input.css'
import hide from './../assets/hide.png'
import show from './../assets/show.png'

const PasswordInput = () => {
    const [showPassword, setShowPassword] = useState(false);

    const togglePasswordVisibility = () => {
        setShowPassword(!showPassword);
    };

    return (
        <div className="password-input">
            <input
                type={showPassword ? 'text' : 'password'}
                id="password-input"
                placeholder="Password"
            />
            <button
                className="password-toggle"
                onClick={togglePasswordVisibility}
            >
                <img src={showPassword ? show : hide} width={17} alt="" />
            </button>
        </div>
    );
};

export default PasswordInput;