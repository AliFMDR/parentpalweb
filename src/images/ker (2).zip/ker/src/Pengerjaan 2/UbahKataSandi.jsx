import "./modal2.css";
import alarm from "./../assets/alarm.svg";
import apkk from "./../assets/app.svg";
import cal from "./../assets/calendar.svg";
import PasswordInput from "./Input";

const UbahSandi = ({ isOpen, onClose }) => {
    if (!isOpen) {
        return null;
    }

    return (
        <div className="modal-overlay">
            <div className="modal">
                <div className="modal-content">
                    <div className="top text-m">
                        <p className="h6 top-text">Ubah Kata Sandi</p>
                    </div>
                    <div className="content ubhkta">
                        <p>Password harus mengandung setidaknya 1 kata, 1 nomor, dan 1 simbol. Panjang minimal adalah 8 karakter kombinasi.</p>
                        <div>
                            <p>Password Sebelumnya</p>
                            <PasswordInput />
                        </div>
                        <div>
                            <p>Password Baru</p>
                            <PasswordInput />
                        </div>
                        <div>
                            <p>Konfirmasi Password Baru</p>
                            <PasswordInput />
                        </div>
                        <div className="progress">
                            <div
                                style={{
                                    height: '10px',
                                    marginTop: '10px',
                                    width: '100%',
                                    backgroundColor: 'lightgray',
                                    marginTop: '5px',
                                    borderRadius: '5px',
                                }}
                            >
                                <div
                                    style={{
                                        height: '100%',
                                        borderRadius: '5px',
                                        //untuk berapa persen
                                        width: '20%',
                                        //untuk warnanya
                                        backgroundColor: 'red',
                                    }}
                                />
                            </div>
                        </div>
                        <p className="last-text">Kami menyarankan anda menggunakan password manager seperti <span>LastPass</span> atau <span>1Pass</span> untuk keamanan akun lebih.</p>
                    </div>
                    <div className="bottom">
                        <button className="batal" onClick={() => onClose()}>Batal</button>
                        <button className="ubah" onClick={() => onClose()}>Ubah Kata Sandi</button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default UbahSandi;
