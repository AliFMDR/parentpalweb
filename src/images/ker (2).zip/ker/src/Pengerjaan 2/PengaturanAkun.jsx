import React, { useState } from 'react'
import profile from "./../assets/profil.png";
import NonaktifKan from './Menonaaktifkan';
import "./pakun.css";
import UbahSandi from './UbahKataSandi';

const PengaturanAkun = () => {
    const [UKS, setUKS] = useState(false);
    const [Nonaktif, setNonaktif] = useState(false);

    const openModalUKS = () => {
        setUKS(true);
    };

    const closeModalUKS = () => {
        setUKS(false);
    };

    const openModalNonaktif = () => {
        setNonaktif(true);
    };

    const closeModalNonaktif = () => {
        setNonaktif(false);
    };
    return (
        <div className="wrapper">
            <p className="judul text-m">
                <span>Pengaturan Akun</span>
            </p>
            <div className="flex-row container-all">
                <div className="hero container-1">
                    <p className='text-m info'>Detail Profil</p>
                    <div className="flex-row ic">
                        <img width={100} src={profile} alt="" />
                        <div className='flex-col usrw'>
                            <p className='usrp'>User Psikolog</p>
                            <div>
                                <button className='ughprf'>Unggah Profile</button>
                                <button className='hps'>Hapus</button>
                            </div>
                            <p>*Gambar harus setidaknya berukuran 320px, dan kurang dari 1MB. File yang diperbolehkan .png / .jpg.</p>
                        </div>
                    </div>
                    <div className='flex-row usrin'>
                        <div className="flex-col">
                            <label htmlFor="username">Username</label>
                            <input type="text" id='username' value={"Username1999"} />
                        </div>
                        <div className="flex-col">
                            <label htmlFor="email">Email</label>
                            <input type="email" id='email' value={"Username1999@mail.com"} />
                        </div>
                        <button className='ughprf'>Verifikasi</button>
                    </div>
                    <div className='flex-row usrin usrin2'>
                        <div className="flex-col">
                            <label htmlFor="firstname">Nama Pertama</label>
                            <input type="text" id='firstname' value={"User"} />
                        </div>
                        <div className="flex-col">
                            <label htmlFor="lastname">Nama Akhir</label>
                            <input type="text" id='lastname' value={"Psikolog"} />
                        </div>
                        <div className="flex-col">
                            <label htmlFor="gelar">Gelar</label>
                            <input type="text" id='gelar' value={"Gelar"} />
                        </div>
                    </div>
                </div>
                <div className="flex-col container-2">
                    <div className="hero ubhkt">
                        <p className="text-m info">Ubah Kata Sandi</p>
                        <p>Kamu dapat mengubah kata sandi atau menghapus akun untuk sementara.</p>
                        <button onClick={()=>openModalUKS()} className='ughprf'>Ubah Kata Sandi</button>
                    </div>
                    <div className="hero ubhkt ttpkun">
                        <p className="text-m info">Tutup Akun</p>
                        <p>Kamu dapat mengubah kata sandi atau menghapus akun untuk sementara.</p>
                        <button onClick={()=>openModalNonaktif()} className='ughprf2'>Tutup Akun</button>
                    </div>
                    <div className="hero">
                        <button className='ughprf'>Simpan Perubahan</button>
                        <UbahSandi isOpen={UKS} onClose={closeModalUKS} />
                        <NonaktifKan isOpen={Nonaktif} onClose={closeModalNonaktif} />
                    </div>
                </div>
            </div>
        </div>
    );
}

export default PengaturanAkun