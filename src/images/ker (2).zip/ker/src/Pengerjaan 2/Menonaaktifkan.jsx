import "./modal2.css";
import alarm from "./../assets/alarm.svg";
import apkk from "./../assets/app.svg";
import cal from "./../assets/calendar.svg";

const NonaktifKan = ({ isOpen, onClose }) => {
    if (!isOpen) {
        return null;
    }

    return (
        <div className="modal-overlay">
            <div className="modal">
                <div className="modal-content">
                    <div className="top text-m">
                        <p className="h6 top-text">Menonaktifkan atau menghapus akun Anda</p>
                    </div>
                    <div className="content ubhkta">
                        <p>Jika Anda ingin berhenti sejenak dari ParentPal, Anda dapat menonaktifkan sementara akun ini. Jika Anda ingin menghapus akun Anda secara permanen, beri tahu kami.</p>
                        <div className="radio-section flex-col">
                            <div className="flex-row atas">
                                <div className="flex-col">
                                    <p className="judul-radio">Nonaktifkan Akun</p>
                                    <p className="text-radio"><span>Menonaktifkan akun Anda bersifat sementara.</span> Akun dan profil utama Anda akan dinonaktifkan dan nama serta foto Anda akan dihapus dari sebagian besar hal yang telah Anda bagikan. Anda dapat terus menggunakan Layanan ParentPal.</p>
                                </div>
                                <input type="radio" name="pilih" value="nonaktif" />
                            </div>
                            <div className="flex-row">
                                <div className="flex-col">
                                    <p className="judul-radio">Hapus Akun</p>
                                    <p className="text-radio"><span>Menghapus akun Anda bersifat permanen.</span> Saat Anda menghapus akun Facebook, Anda tidak akan dapat mengambil kembali konten atau informasi yang telah Anda bagikan di Facebook. Profil utama Anda, Messenger, dan semua pesan Anda juga akan dihapus.</p>
                                </div>
                                <input type="radio" name="pilih" value="hapus" />
                            </div>
                        </div>
                    </div>
                </div>
                <div className="bottom">
                    <button className="btl" onClick={() => onClose()}>Batal</button>
                    <button className="batal" onClick={() => onClose()}>Simpan Perubahan</button>
                </div>
            </div>
        </div>
    );
};

export default NonaktifKan;
