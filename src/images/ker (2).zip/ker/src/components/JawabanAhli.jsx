import React, { useState } from 'react';
import './JawabanItem.css';

const JawabanAhli = ({ akun, role, waktu, pertanyaan, deskripsi, profilePhoto }) => {
  const [answer, setAnswer] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Jawaban:', answer);
  };

  return (
    <div className="jawaban-ahli-container">
      <div className="user-info">
        <div>
          <h2>Nama Akun: {akun}</h2>
          <h3>Peran: {role}</h3>
        </div>
        <div>
          <img src={profilePhoto} alt="Foto Profil" />
        </div>
      </div>
      <div className="question-info">
        <p>Waktu: {waktu}</p>
        <p>Pertanyaan: {pertanyaan}</p>
        <p>Deskripsi Pertanyaan: {deskripsi}</p>
      </div>
      <form onSubmit={handleSubmit}>
        <textarea
          value={answer}
          onChange={(e) => setAnswer(e.target.value)}
          placeholder="Ketikkan komentar Anda disini..."
          required
        ></textarea>
        <button type="submit">Upload</button>
      </form>
    </div>
  );
};

export default JawabanAhli;