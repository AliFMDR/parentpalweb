import React, { useState } from 'react';
import profileImg from "../images/profile.png";
import komentarImg from "../images/chat.png";
import './TanyaAhliPublikItem.css';

const TanyaAhliPublik = () => {
  const [sortOrder, setSortOrder] = useState('terbaru');

  const handleSortChange = (order) => {
    setSortOrder(order);
  };

  const questions = [
    {
      id: 1,
      pertanyaan: "Anak saya sering mengalami kecemasan dan takut berlebihan. Apa yang bisa saya lakukan untuk membantunya?",
      deskripsi: "Anak tersebut seringkali merasa cemas dan takut, bahkan dalam situasi yang seharusnya tidak menimbulkan kecemasan yang berlebihan. Ibu ingin mengetahui strategi yang efektif untuk membantu anak mengatasi kecemasannya.",
      user: {
        name: "Eva Pratiwi",
        profileImage: "profile.png",
        role: "Ibu"
      },
      waktu: "17 Jun 2022  12:31 PM",
      commentCount: 5
    },
    
    {
        id: 2,
        pertanyaan: "Anak saya sering mengalami kecemasan dan takut berlebihan. Apa yang bisa saya lakukan untuk membantunya?",
        deskripsi: "Anak tersebut seringkali merasa cemas dan takut, bahkan dalam situasi yang seharusnya tidak menimbulkan kecemasan yang berlebihan. Ibu ingin mengetahui strategi yang efektif untuk membantu anak mengatasi kecemasannya.",
        user: {
          name: "Eva Pratiwi",
          profileImage: "profile.png",
          role: "Ayah"
        },
        waktu: "10 Jun 2022  01:31 AM",
        commentCount: 2
    },

    {
        id: 3,
        pertanyaan: "Anak saya sering mengalami kecemasan dan takut berlebihan. Apa yang bisa saya lakukan untuk membantunya?",
        deskripsi: "Anak tersebut seringkali merasa cemas dan takut, bahkan dalam situasi yang seharusnya tidak menimbulkan kecemasan yang berlebihan. Ibu ingin mengetahui strategi yang efektif untuk membantu anak mengatasi kecemasannya.",
        user: {
          name: "Eva Pratiwi",
          profileImage: "profile.png",
          role: "Ayah"
        },
        waktu: "17 Mei 2022  16:29 PM",
        commentCount: 3
    },

    {
        id: 4,
        pertanyaan: "Anak saya sering mengalami kecemasan dan takut berlebihan. Apa yang bisa saya lakukan untuk membantunya?",
        deskripsi: "Anak tersebut seringkali merasa cemas dan takut, bahkan dalam situasi yang seharusnya tidak menimbulkan kecemasan yang berlebihan. Ibu ingin mengetahui strategi yang efektif untuk membantu anak mengatasi kecemasannya.",
        user: {
          name: "Eva Pratiwi",
          profileImage: "profile.png",
          role: "Ibu"
        },
        waktu: "01 Jun 2022  00:00 AM",
        commentCount: 9
    },

    {
        id: 5,
        pertanyaan: "Anak saya sering mengalami kecemasan dan takut berlebihan. Apa yang bisa saya lakukan untuk membantunya?",
        deskripsi: "Anak tersebut seringkali merasa cemas dan takut, bahkan dalam situasi yang seharusnya tidak menimbulkan kecemasan yang berlebihan. Ibu ingin mengetahui strategi yang efektif untuk membantu anak mengatasi kecemasannya.",
        user: {
          name: "Eva Pratiwi",
          profileImage: "profile.png",
          role: "Ibu"
        },
        waktu: "17 Mei 2022  06:20 PM",
        commentCount: 6
    },

    {
        id: 6,
        pertanyaan: "Anak saya sering mengalami kecemasan dan takut berlebihan. Apa yang bisa saya lakukan untuk membantunya?",
        deskripsi: "Anak tersebut seringkali merasa cemas dan takut, bahkan dalam situasi yang seharusnya tidak menimbulkan kecemasan yang berlebihan. Ibu ingin mengetahui strategi yang efektif untuk membantu anak mengatasi kecemasannya.",
        user: {
          name: "Eva Pratiwi",
          profileImage: "profile.png",
          role: "Ayah"
        },
        waktu: "28 Jun 2022  09:37 AM",
        commentCount: 1
    }
  ];

  let filteredQuestions = [...questions];

  if (sortOrder === 'terbaru') {
    filteredQuestions.sort((a, b) => {
      const dateA = new Date(a.waktu);
      const dateB = new Date(b.waktu);
      return dateB - dateA;
    });
  } else if (sortOrder === 'terlama') {
    filteredQuestions.sort((a, b) => {
      const dateA = new Date(a.waktu);
      const dateB = new Date(b.waktu);
      return dateA - dateB;
    });
  }

  return (
    <div>
      <div style={{ margin: 'auto'}}>
        <h1 style={{ marginTop: '40px', marginBottom: '20px'}}>
          <span style={{ color: "gray", fontSize: "20px" }}>Beranda </span>
          <span style={{ color: "#07294A", fontSize: "20px" }}>Tanya Ahli (Publik)</span>
        </h1>
      </div>
      <div className='filter'>
        <span>Urut Berdasar:</span>
        <select value={sortOrder} onChange={(e) => handleSortChange(e.target.value)} className='option'>
          <option value="semua">Semua</option>
          <option value="terbaru">Terbaru</option>
          <option value="terlama">Terlama</option>
        </select>
      </div>
      <div className="card-container">
        {filteredQuestions.map((question) => (
          <div
            key={question.id}
            className="card"
            onClick={() => handleCardClick(question.id)}
          >
            <div className="pertanyaan">{question.pertanyaan}</div>
            <div className="deskripsi">{question.deskripsi}</div>
            <div className="user">
              <img src={profileImg} alt="Profil Pengguna" />
              <span>Di Posting oleh</span>
              <span className="username">{question.user.name}</span>
              <span className="waktu">{question.waktu}</span>
              <img src={komentarImg} alt="Ikon Komentar" />
              <span>{question.commentCount}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TanyaAhliPublik;