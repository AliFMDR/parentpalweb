import React, { useState } from 'react';
import peringatanImage from '../images/peringatan.png';
import gambarImage from '../images/gambar.png';

const LupaPassword = () => {
  const [email, setEmail] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    // Logika untuk mengirim email lupa password
    console.log(`Email lupa password dikirim ke: ${email}`);
    
    // Contoh pengecekan email tidak ditemukan
    if (email === '') {
      setErrorMessage('Maaf, akun dengan email yang Anda masukkan tidak ditemukan, masukkan kembali email dengan akun yang pernah terdaftar.');
    } else {
      setErrorMessage('');
    }
  };

  const handleGoBack = () => {
    // Logika untuk kembali ke halaman sebelumnya
    console.log('Kembali ke Login');
  };

  return (
    <div style={styles.container}>
      <h1 style={styles.heading}>Lupa Password?</h1>
      <h2 style={styles.heading2}>Jangan khawatir, kami akan mengirimkan instruksi lebih lanjut ke email Anda.</h2><img src={gambarImage} alt="Gambar" style={styles.image} />
      <form onSubmit={handleSubmit}>
        <div style={styles.inputContainer}>
          <input
            type="email"
            id="email"
            placeholder="masukkan email akun terdaftar"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            style={styles.input}
          />
        </div>
        {errorMessage && (
          <div style={styles.errorMessage}>
            <img src={peringatanImage} alt="Peringatan" style={styles.alertImage} />
            {errorMessage}
          </div>
        )}
        <br></br>
        <button type="submit" style={styles.button}>Reset Password</button>
        <br></br>
        <button onClick={handleGoBack} style={styles.goBackButton}>Kembali ke Login</button>
      </form>
    </div>
  );
};

const styles = {
  container: {
    backgroundColor: '#ffffff',
    padding: '80px',
    borderRadius: '5px',
    maxWidth: '1090px',
    margin: '70px auto',
    boxShadow: '0 7px 7px rgba(0, 0, 0, 0.1)',
  },
  heading: {
    fontSize: '32px',
    marginBottom: '5px',
    color: '#313140',
    fontWeight: 'bold',
  },
  heading2: {
    fontSize: '15px',
    color: '#6C757E',
    maxWidth: '420px',
    marginBottom: '30px'
  },
  inputContainer: {
    display: 'flex',
    alignItems: 'center',
  },
  input: {
    width: '420px',
    height: '50px',
    padding: '10px',
    borderRadius: '5px',
    border: 'none',
    backgroundColor: '#BDE1F1',
    color: '#6C757E',
    fontSize: '12px'
  },
  image: {
    position: 'absolute',
    top: '50%',
    right: '100px',
    transform: 'translateY(-50%)',
    height: '520px',
  },
  button: {
    width: '420px',
    backgroundColor: '#0072C6',
    color: 'white',
    border: 'none',
    borderRadius: '5px',
    padding: '10px 20px',
    cursor: 'pointer',
    marginTop: '0px',
    marginBottom: '5px',
  },
  goBackButton: {
    width: '420px',
    backgroundColor: '#ffffff',
    border: '1px solid #0072C6',
    borderRadius: '5px',
    padding: '10px 20px',
    cursor: 'pointer',
    marginBottom: '60px'
  },
  errorMessage: {
    width: '420px',
    height: '80px',
    display: 'flex',
    alignItems: 'center',
    fontSize: '10px',
    color: '#6C757E',
    backgroundColor: '#FFC001',
    padding: '5px',
    borderRadius: '5px',
  },
  alertImage: {
    height: '30px',
    marginRight: '20px',
    marginLeft: '30px'
  },
};

export default LupaPassword;