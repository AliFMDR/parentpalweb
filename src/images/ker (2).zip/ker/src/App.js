import React, { useState } from "react";
import PengaturanAkun from "./Pengerjaan 2/PengaturanAkun";

function App() {

    return (
        <div>
            <PengaturanAkun/>
        </div>
    );
}

export default App;
