//DPN = Detail Penolakan
import "./modal.css";
import React from "react";

const DPN = ({ isOpen, onClose }) => {
    if (!isOpen) {
        return null;
    }

    return (
        <div className="modal-overlay">
            <div className="modal">
                <div className="modal-content dpn">
                    <div className="top text-m">
                        <p className="h6 top-text">Detail</p>
                        <p className="h6 dpn-text">Anda telah menolak jadwal webinar ini.</p>
                    </div>
                    <div className="bottom">
                        <button className="wtt modal-tutup text-m" onClick={onClose}>
                            Tutup
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default DPN;
