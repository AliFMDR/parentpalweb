import React from "react";
import "./modal.css";
import alarm from "./../assets/alarm.svg";
import apkk from "./../assets/app.svg";
import cal from "./../assets/calendar.svg";

const WebinarTelahTerjadwal = ({ isOpen, onClose }) => {
    if (!isOpen) {
        return null;
    }

    return (
        <div className="modal-overlay">
            <div className="modal">
                <div className="modal-content">
                    <div className="top text-m">
                        <p className="h6 top-text">Webinar Telah Terjadwal</p>
                        <p className="small text-m">Topik:</p>
                        <p className="h6">Memperkuat Peran Orangtua: Membangun Anak yang Tangguh dan Bahagia</p>
                        <p className="small text-m">Media:</p>
                        <p className="h6">Zoom Meeting (Daring/Online)</p>
                        <p className="small text-m">Waktu:</p>
                        <p className="h6 time">
                            <img src={cal} alt="" />
                            17 Juni 2023
                        </p>
                        <p className="h6 time">
                            <img src={alarm} alt="" />
                            19:00 - 20:00 WIB
                        </p>
                        <p className="small text-m">Tautan pendukung:</p>
                        <p className="link">https://goo.gl/gabungWebinar000</p>
                        <p className="moderator text-m">
                            <img src={apkk} alt="" />
                            Moderator oleh <span>Tim ParentPal</span>
                        </p>
                    </div>
                    <div className="bottom">
                        <button className="wtt modal-tutup text-m" onClick={onClose}>
                            Tutup
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default WebinarTelahTerjadwal;
