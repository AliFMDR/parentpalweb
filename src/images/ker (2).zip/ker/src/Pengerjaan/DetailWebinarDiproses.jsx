import React from "react";
import "./modal.css";
import alarm from "./../assets/alarm.svg";
import apkk from "./../assets/app.svg";
import cal from "./../assets/calendar.svg";

const DetailWebinarDiproses = ({ isOpen, onClose }) => {
    if (!isOpen) {
        return null;
    }

    return (
        <div className="modal-overlay">
            <div className="modal">
                <div className="modal-content">
                    <div className="top text-m">
                        <p className="h6 top-text">Detail Webinar(Sedang diproses oleh admin terkait)</p>
                        <p className="small text-m">Topik:</p>
                        <p className="h6">Memperkuat Peran Orangtua: Membangun Anak yang Tangguh dan Bahagia</p>
                        <p className="small text-m">Media:</p>
                        <p className="h6">Zoom Meeting (Daring/Online)</p>
                        <p className="small text-m">Waktu:</p>
                        <p className="h6 time">
                            <img src={cal} alt="" />
                            17 Juni 2023
                        </p>
                        <p className="h6 time">
                            <img src={alarm} alt="" />
                            19:00 - 20:00 WIB
                        </p>
                        <p className="small text-m">Catatan:</p>
                        <p className="text-m text-red">CatatanCatatanCatatanCatatanCatatanCatatan</p>
                        <p className="moderator text-m">
                            <img src={apkk} alt="" />
                            Moderator oleh <span>Tim ParentPal</span>
                        </p>
                    </div>
                    <div className="bottom">
                        <button className="modal-tutup text-m" onClick={onClose}>
                            Tutup
                        </button>
                        <button className="modal-hapus text-m" onClick={onClose}>
                            Hapus
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default DetailWebinarDiproses;
