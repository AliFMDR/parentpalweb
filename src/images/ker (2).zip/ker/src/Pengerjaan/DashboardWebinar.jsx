import React from "react";
import profile from "./../assets/profil.png";
import "./dshweb.css";

const DashboardWebinar = () => {
    return (
        <div className="wrapper">
            <p className="judul text-m">
                Beranda <span>Webinar</span>
            </p>
            <div className="hero">
                <div className="flex-row ic">
                    <p className="prl text-m">Perlihatkan</p>
                    <select className="entrysel" name="entry" id="entry">
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5" selected>
                            5
                        </option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                        <option value="9">9</option>
                        <option value="10">10</option>
                    </select>
                    <p className="prl text-m">Entri</p>
                    <div className="flex-col ml-3">
                        <p className="urut text-m">Urut Berdasar</p>
                        <select className="katsel" name="urut" id="urut">
                            <option value="Terbaru" selected>
                                Terbaru
                            </option>
                            <option value="Terlama">Terlama</option>
                        </select>
                    </div>
                    <div className="flex-col ml-3">
                        <p className="urut text-m">Kategori</p>
                        <select className="katsel" name="kategori" id="kategori">
                            <option value="Terjadwal" selected>
                                Terjadwal
                            </option>
                            <option value="Tak Terjadwal">Tak Terjadwal</option>
                        </select>
                    </div>
                </div>
                <div className="table-c">
                    <table>
                        <thead>
                            <tr>
                                <td>
                                    <input type="checkbox" name="select" id="select" />
                                </td>
                                <td>Nama Pengundang</td>
                                <td>Detail</td>
                                <td>Status</td>
                                <td>Aksi</td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td></td>
                                <td>
                                    <div className="flex-row tr-1 ic">
                                        <img width={60} height={60} src={profile} alt="" />
                                        <div className="flex-col">
                                            <p className="user">User Admin 1</p>
                                            <p>ADMIN</p>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div className="flex-col tr-2">
                                        <p>Memperkuat Peran Orangtua: Membangun Anak yang Tangguh dan Bahagia</p>
                                        <p className="tanggal">1 Jun 2023 12:00 WIB</p>
                                    </div>
                                </td>
                                <td>
                                    <div className="td-3 flex-row jc ic">
                                        <p className="status terjadwal">Terjadwal</p>
                                    </div>
                                </td>
                                <td className="flex-row jc ic">
                                    <button className="aksi">...</button>
                                </td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>
                                    <div className="flex-row tr-1 ic">
                                        <img width={60} height={60} src={profile} alt="" />
                                        <div className="flex-col">
                                            <p className="user">User Admin 1</p>
                                            <p>ADMIN</p>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div className="flex-col tr-2">
                                        <p>Memperkuat Peran Orangtua: Membangun Anak yang Tangguh dan Bahagia</p>
                                        <p className="tanggal">1 Jun 2023 12:00 WIB</p>
                                    </div>
                                </td>
                                <td>
                                    <div className="td-3 flex-row jc ic">
                                        <p className="status menunggu">Menunggu</p>
                                    </div>
                                </td>
                                <td className="flex-row jc ic">
                                    <button className="aksi">...</button>
                                </td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>
                                    <div className="flex-row tr-1 ic">
                                        <img width={60} height={60} src={profile} alt="" />
                                        <div className="flex-col">
                                            <p className="user">User Admin 1</p>
                                            <p>ADMIN</p>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div className="flex-col tr-2">
                                        <p>Memperkuat Peran Orangtua: Membangun Anak yang Tangguh dan Bahagia</p>
                                        <p className="tanggal">1 Jun 2023 12:00 WIB</p>
                                    </div>
                                </td>
                                <td>
                                    <div className="td-3 flex-row jc ic">
                                        <p className="status proses">Sedang Diproses</p>
                                    </div>
                                </td>
                                <td className="flex-row jc ic">
                                    <button className="aksi">...</button>
                                </td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>
                                    <div className="flex-row tr-1 ic">
                                        <img width={60} height={60} src={profile} alt="" />
                                        <div className="flex-col">
                                            <p className="user">User Admin 1</p>
                                            <p>ADMIN</p>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div className="flex-col tr-2">
                                        <p>Memperkuat Peran Orangtua: Membangun Anak yang Tangguh dan Bahagia</p>
                                        <p className="tanggal">1 Jun 2023 12:00 WIB</p>
                                    </div>
                                </td>
                                <td>
                                    <div className="td-3 flex-row jc ic">
                                        <p className="status ditolak">Ditolak</p>
                                    </div>
                                </td>
                                <td className="flex-row jc ic">
                                    <button className="aksi">...</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default DashboardWebinar;
