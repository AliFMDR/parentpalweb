export function getLists() {
    return fetch("http://localhost:3333/list").then((data) => data.json());
}
